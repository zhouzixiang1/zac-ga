OPENQASM 2.0;
include "qelib1.inc";

qreg q[14];
x q[0];
cz q[0],q[1];
cz q[2],q[3];
cz q[4],q[5];
cz q[6],q[7];
cz q[8],q[9];
cz q[10],q[11];
cz q[12],q[13];
x q[5];
cz q[0],q[4];
cz q[2],q[5];
